<?php
// connect to database
$db = mysqli_connect('localhost', 'root', '', 'vhub');

// REGISTER USER
if (isset($_POST['reg_user'])) {
	// receive all input values from the form
	
	
	$Name = mysqli_real_escape_string($db, $_POST['Name']);
	$Rollno = mysqli_real_escape_string($db, $_POST['Rollno']);
	$Branch = mysqli_real_escape_string($db, $_POST['Branch']);
	$Phno = mysqli_real_escape_string($db, $_POST['Phno']);
	$Club = mysqli_real_escape_string($db, $_POST['Club']);
	$Subclub = mysqli_real_escape_string($db, $_POST['Subclub']);
	$Role = mysqli_real_escape_string($db, $_POST['Role']);

	// form validation: ensure that the form is correctly filled
	if (empty($Name)) { array_push($errors, "Name is required"); }
	if (empty($Rollno)) { array_push($errors, "Roll Number is required"); }
	if (empty($Branch)) { array_push($errors, "Branch is required"); }
	if (empty($Phno)) { array_push($errors, "Phone Number is required"); }
	if (empty($Club)) { array_push($errors, "Club Name is required"); }

	// register user if there are no errors in the form
	if (count($errors) == 0) {
		
		$query = "INSERT INTO jyo (Name,Rollno,Branch,Phno,Club,Subclub,Role) 
				  VALUES('$Name', '$Rollno', '$Branch', '$Phno', '$Club', '$Subclub', '$Role')";
		mysqli_query($db, $query);

		$_SESSION['Name'] = $Name;
		$_SESSION['success'] = "You are Successfully Registered";
		header('location: home.html');
		echo"<center>"."You are Successfully Registered"."</center>";
		
	}

}

// LOGIN USER
if (isset($_POST['login_user'])) {
	$username = mysqli_real_escape_string($db, $_POST['username']);
	$password = mysqli_real_escape_string($db, $_POST['password']);

	
	if ($username==$username&&$password==$password) {
		
		$query = "SELECT * FROM patients WHERE username='$username' AND password='$password'";
		$results = mysqli_query($db, $query);

		if (mysqli_num_rows($results) == 1) {
			$_SESSION['username'] = $username;
			$_SESSION['success'] = "You are now logged in";
			header('location: patient-mydetails.php');
		}else {
			echo"<center>"."Wrong username/password combination"."</center>";
		}
	}
}

?>