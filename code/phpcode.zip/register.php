<?php include('registerserver.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<style>
body {
       background: url(image.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
</style>
	<div class="header">
		<h2>Registration</h2>
	</div>
	
	<form method="post" action="register.php">


		<div class="input-group">
			<label>Name</label>
			<input type="text" name="Name">
		</div>
		<div class="input-group">
			<label>Roll Number</label>
			<input type="text" name="Rollno">
		</div>
		<div class="input-group">
			<label>Branch</label>
			<input type="text" name="Branch">
		</div>
		<div class="input-group">
			<label>Phone no.</label>
			<input type="text" name="Phno">
		</div>
		<div class="input-group">
			<label>Club</label>
			<input type="text" name="Club">
		</div>
		<div class="input-group">
			<label>Sub-Club</label>
			<input type="text" name="Subclub">
		</div>
		<div class="input-group">
			<label>Role</label>
			<input type="text" name="Role">
		</div>
		<div class="input-group">
			<label>Date</label>
			<input type="text" name="Role">
		</div>
		<div class="input-group">
			<button type="submit" class="btn" name="reg_user">Register</button>
		</div>
		
	</form>
</body>
</html>